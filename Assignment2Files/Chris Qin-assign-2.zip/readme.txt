[Chris Qin], [A00944299], [A], [October 9, 2018]

This assignment is [100]% complete.


------------------------
Question one (PhoneNumbers) status:

[complete]

------------------------
Question two (CylinderStats) status:

[complete]

------------------------
Question three (Cylinder) status:

[complete]

------------------------
Question four (Box) status:

[complete]

------------------------
Question five (Email) status:

[complete]
