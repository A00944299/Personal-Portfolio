[Chris Qin], [A00944299], [A], [December 5th, 2018]

This assignment is [enter percent]% complete.


------------------------
Question one (Statistics) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (DrawStar) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (TestMIXChar) status:

[incomplete]
[Did not understand how to convert back to a java char. Lack of time to finish.]
