[Student Name], [Student ID], [Set], [Date]

This assignment is [enter percent]% complete.


------------------------
Question one (Statistics) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (DrawStar) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (TestMIXChar) status:

[complete or not complete]
[explanation if not complete, what is working/not working]
